function [xd,yd,coeficients]=dibuixaSplineParabolic(x,y)
% [xd,yd,coeficients]=dibuixaSplineCubic(x,S,dS,d2S)
%
% Funció per dibuixar un spline cúbic C2
% x  : coordenades dels punts base
% S  : valors de la funció als punts base
% dS : valors de la segona derivada o []
% d2S: valors de la segona derivada o [] (només es fa servir si dS=[])
%
% Es pot dibuixar amb
%  plot(xd,yd)
%

xd = []; yd = []; coeficients = [];
x01 = [0:1/20:1]; %20 subintervals a cada interval

h=x(2:end)-x(1:end-1);
t=y(2:end)-y(1:end-1);
dS=zeros(1, length(x));
dS(1)=t(1)/h(1);

for i=1:length(x)-1
    a = (t(i)-h(i)*dS(i))/(h(i)**2);
    b = dS(i);
    c = y(i);
    dS(i+1) = 2*(t(i)/h(i)) - dS(i);
    xs = x(i)+x01*h(i); %valors de x a l'interval
    ys = a*(xs-x(i)).^3 + b*(xs-x(i)).^2 + c*(xs-x(i)) + d;
    xd = [xd xs]; yd = [yd ys]; coeficients=[coeficients; a b c d];
end

%plot(xd,yd);
