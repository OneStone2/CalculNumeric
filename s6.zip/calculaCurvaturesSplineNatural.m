function d2S = calculaCurvaturesSplineNatural(x,y)

h = x(2:end)-x(1:end-1);
t = y(2:end)-y(1:end-1);
l = (h(2:end))./(h(2:end)+h(1:end.-1));
m = (h(1:end-1))./(h(2:end)+h(1:end.-1));
d = (t(2:end)./h(2:end)-t(1:end-1)./h(1:end-1))./(h(2:end)+h(1:end-1))*6;
A = gallery("tridiag", m(2:end), 2*ones(1, length(m)), l(1:end-1));
d2S = zeros(length(x), 1);
d2S(2:end-1) = A\d';
