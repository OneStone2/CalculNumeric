clear all
format long

x1 = input("Escriu x1 inicial\n");
x2 = input("Escriu x2 inicial\n");
x3 = input("Escriu x3 inicial\n");
x0 = [x1; x2; x3]
niter = input("Escriu el nombre d'iteracions\n");
[vect_x2,vect_r2] = newton_raphson(x0,niter,@f,@derivada)
