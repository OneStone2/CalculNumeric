r=2;
c=2;
f = @(x)(1./(1+25*x.**2));
for i=1:r*c
    n=2*i;
    x0 = linspace(-1, 1, n+1);
    y0 = f(x0);
    p = polyfit(x0, y0, n);
    subplot(r, 2*c, i);
    x = linspace(-1, 1);
    y = polyval(p, x);
    y1 = ones(1, length(x))./(1+25*x.**2);
    figure(1)
    plot(x,y1,'k-',x,y,'r-','LineWidth',2)
end

for i=1:r*c
    n=2*i;
    x0 = linspace(-1, 1, 101);
    y0 = f(x0);
    p = polyfit(x0, y0, n);
    rd = @(x)((polyval(p, x)-f(x)).**2);
    n
    sum(rd(x0))
    sqrt(quad(rd, -1, 1))
    subplot(r, 2*c, i+4);
    x = linspace(-1, 1);
    y = polyval(p, x);
    y1 = ones(1, length(x))./(1+25*x.**2);
    figure(1)
    plot(x,y1,'k-',x,y,'b-','LineWidth',2)
end
