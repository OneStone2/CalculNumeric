r=2;
c=2;
f = @(x)(1./(1+25*x.^2));
for i=1:r*c
    n=2*i;
    x0 = linspace(-1, 1, n+1);
    y0 = f(x0);
    A = zeros(n+1, n+1);
    for j=0:n
        for k=0:n
            g = @(x)(legendreP(j, x).*legendreP(k, x));
            A(j+1, k+1) = sqrt(integral(g, -1, 1));
        end
    end
    A
    p = polyfit(x0, y0, n);
    subplot(r, 2*c, i);
    x = linspace(-1, 1);
    y = polyval(p, x);
    y1 = ones(1, length(x))./(1+25*x.^2);
    figure(1)
    plot(x,y1,'k-',x,y,'r-','LineWidth',2)
end
