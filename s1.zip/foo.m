clear all
format long

x0 = input("Escriu el limit inferior de l'interval\n");
x1 = input("Escriu el limit superior de l'interval\n");
tol = input("Escriu la tolerancia\n");
[vect_x1,vect_r1] = biseccio_iter([x0, x1],tol,@poly);
%x0 = input("Escriu l'aproximacio inicial\n");
%tol = input("Escriu la tolerancia\n");
[vect_x2,vect_r2] = newton_iter(x0,tol,@poly,@deriv);
i1 = 1:length(vect_r1);
i2 = 1:length(vect_r2);
figure(1), semilogy(i1,vect_r1(i1),'-o',i2,vect_r2(i2),'-o')
