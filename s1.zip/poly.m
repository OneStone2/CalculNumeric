function y = poly(x)
q = [1, -4, 7, -21, 6, 18];
y = polyval(q, x);
