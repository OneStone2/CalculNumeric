function [vect_x,vect_r] = biseccio_iter(Ini,tol,f)
% 
% [vect_x,vect_r] = biseccio_iter(Ini,f)

vect_x = []; 
vect_r = [];
x0 = Ini(1); f0 = f(x0); 
a =  Ini(2); fa = f(a); 
r = Inf;
if f0*fa > 0 
    error('Interval inicial inadequat')
end
while abs(r)>tol || abs(f(x0))>tol
    x1 = (x0 + a)/2; 
    f1 = f(x1);
    r = abs((x1-x0)/x1);
    
    vect_x = [vect_x;x0]; 
    vect_r = [vect_r;r];
    
    if f1*f0 < 0
        a = x0; fa = f0; 
    end
    
    x0 = x1; f0 = f1; 
end
