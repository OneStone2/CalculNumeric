function y = deriv(x)
q = [1, -4, 7, -21, 6, 18];
y = polyval(polyder(q), x);
