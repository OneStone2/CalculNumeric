function [vect_x,vect_r] = newton_iter(Ini,tol,f,d)
% 
% [vect_x,vect_r] = newton_iter(Ini,tol,f,d)

vect_x = []; 
vect_r = [];
x = Ini;
r = Inf;
while abs(r)>tol || abs(f(x))>tol
    x1 = x - f(x)/d(x);
    r = abs((x1-x)/x1);
    
    vect_x = [vect_x;x]; 
    vect_r = [vect_r;r]; 
    
    x = x1;
end
