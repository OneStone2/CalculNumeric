function U = parabolicBackwardEuler(x,Ax,At,nOfSteps,nOfStepsPlot,ua,ub,f)

%Initialization
N = size(f)(1)
Un = zeros(N, 1);
Unm1 = f; %solution at time n-1
U = f;
diff = 1;

r = At/Ax^2;

c = e = -r*ones(1, N-3);
d = (1+2*r)*ones(1, N-2);

M = (gallery("tridiag", N-2, c, d, e))**-1;

%Loop in time steps
for n=1:nOfSteps
    Un(1)=ua(n+1); Un(end)=ub(n+1); % boundary conditions  
    V=zeros(N-2,1); V(1)=ua(n+1); V(end)=ub(n+1);
    %interior nodes
    Un(2:end-1)=M*(Unm1(2:end-1)+r*V);
    
    if ( mod(n,nOfStepsPlot)==0 | n==nOfSteps )
        U = [U Un];
    end
    Unm1 = Un; %next step
end

