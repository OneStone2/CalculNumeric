% Objectius:
% - Entendre els conceptes basics dels metodes per a la resolucio numerica
% d'EDOs.
% - Implementar un metode per resoldre EDOs (metode d'Euler)
% - Comprovar experimentalment la convergencia d'un metode
%
% Tasques a fer:
% 1) Executar i mirar aquest script per veure com es pot resoldre el 
%    problema de valor inicial (PVI) amb la funcio de Matlab ode45
% 2) Implementar el metode d'Euler per a la resolucio del mateix PVI
%    Cal crear la funcio Euler amb els arguments d'entrada i sortida
%    especificats a aquest script. 
% 3) Dibuixar una grafica de log10(abs(error)) en funcio de log10(h), on l'error
%    s'evalua com la diferencia entre la solucio analitica i la solucio
%    numerica per x=2. Comprovar si l'ordre de convergencia coincideix amb
%    el teoric.
% Es proposa ara resoldre el PVI y''= -y, y(0)=1, y'(0)=0 per x en (0,T)
% 4) Reduir la EDO de segon ordre a un sistema d'EDOs de 1er ordre
%    Resoldre numericament el PVI amb el metode d'Euler per T=2*pi. Comprovar
%    la converg?ncia.
% 5) Amb h=0.01 resoldre el problema per T=10*pi,50*pi. ?s el m?tode
%    (absolutament) estable? 
close all;

% Resolucio de la EDO dy/dx = -y/(10x+1) per x en (0,1) 
% amb condicio inicial y(0)=1
%f=@(x,y) -y/(10*x+1); a=0; b=1;  y0=1;
%f=@(x,y) [y(2), -y(1)]; a=0; b=50*pi;  y0=[1, 0];

format long;

R = 0.00132;
g = -9.8;
v0 = 100;
theta = pi/4;
f=@(x,y) [y(3), y(4), -R*y(3)*sqrt(y(3)**2+y(4)**2), -R*y(4)*sqrt(y(3)**2+y(4)**2)+g]; a=0; b=1000; y0=[0, 0, v0*cos(theta), v0*sin(theta)];

%Solucio analitica
%yanal = @(x)(1./(1 + 10.*x).^(0.1));
%yanal = @(x)(cos(x));
figure(1)
hold on
x = linspace(a,b,1000);
%plot(x,yanal(x),'-') 
%legend('sol. analitica')

option = odeset('Events', @myEvent);

%Solucio amb funcions intrinseques de Matlab




[x,Y]=ode45(f,[a,b],y0,option);
x
Y
figure(1), hold on, plot(x,Y,'-*'), legend('sol. analitica','ode45')

%[x,Y]=Euler(f,[a,b],y0, 1000);
%Y(end, 1:2)


%Solucio amb el metode d'Euler
%h=0.02;
%npassos=ceil((b-a)/h); 

%res=[];

%for m=1:500
%    [x,Y]=Euler(f,[a,b],y0,m);
%    res=[res;Y(end, 1:2)];
%end

%res

%x=[];
%r=[];
%for i=20:250
%    E = norm(res(i,:)-res(2*i,:));
%    r = [r;E/norm(res(2*i,:))];
%    x = [x;i];
%end

%figure(1), hold on,plot(log10(x),log10(r),'-b'), legend('Euler'), xlabel('log10(m)'), ylabel('log10(r)')

%m=20;
%[x,Y]=Euler(f,[a,b],y0,m);
%figure(1), hold on,plot(Y(:, 1),Y(:, 2),'-g'), legend('Euler-20')
%Solucio amb el metode d'Euler enrera
%npassos=ceil((b-a)/h); 
%[x,Y]=BackwardEuler(f,[a,b],y0,npassos);
%figure(1), plot(x,Y(:, 1),'-r')
%title('y')
%legend('sol. analitica','euler','euler enrera')
