function [position,isterminal,direction] = myEvent(x,Y)
position = Y(2);
isterminal = 1;
direction = -1;
