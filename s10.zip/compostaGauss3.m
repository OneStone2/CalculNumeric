function Iaprox=compostaGauss3(f,a,b,m)

x = linspace(a,b,m+1);
Iaprox = 0;

for i=1:m
    a = x(i); b = x(i+1);
    f2 = @(t)(f((t+1)*(b-a)/2+a)*(b-a)/2);
    w = [5/9   8/9   5/9];
    z = [-sqrt(3/5); 0; sqrt(3/5)];
    Iaprox = Iaprox + w*f2(z);
end
