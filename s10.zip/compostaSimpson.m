function Iaprox=compostaSimpson(f,a,b,m)

x = linspace(a,b,2*m+1);
h = (b-a)/(2*m);
Iaprox = (feval(f, x(1))+feval(f, x(2*m+1)))*h/3;

for i=2:2*m
    y = feval(f, x(i));
    if mod(i, 2) == 0
        Iaprox += 4*y*h/3;
    else
        Iaprox += 2*y*h/3;
    end
end
