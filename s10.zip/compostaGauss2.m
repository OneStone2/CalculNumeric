function Iaprox=compostaGauss2(f,a,b,m)

x = linspace(a,b,m+1);
Iaprox = 0;

for i=1:m
    a = x(i); b = x(i+1);
    f2 = @(t)(f((t+1)*(b-a)/2+a)*(b-a)/2);
    w = [1 1];
    z = [-1/sqrt(3); 1/sqrt(3)];
    Iaprox = Iaprox + w*f2(z);
end
