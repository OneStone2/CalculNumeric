function [x,Y]=BackwardEuler(f,I,y0,npassos)
a = I(1);
b = I(2);
h = (b-a)/npassos;
y1 = y0;
x = linspace(a, b, npassos+1);
Y = [y1];
for i=1:npassos
    g = @(y)(y1+h*f(x(i+1), y)-y);
    y1 = fsolve(g, y1);
    Y = [Y; y1];
end
