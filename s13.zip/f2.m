function res=f2(t,y)
res=[y(1)+2*y(1)*y(2)
    -y(1)*t+2*y(2)];