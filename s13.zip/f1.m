function res=f1(x,y)
res=2*x*y+y^2*sin(y);
