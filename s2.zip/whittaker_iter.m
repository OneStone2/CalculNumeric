function [vect_x,vect_r] = whittaker_iter(Ini,m,tol,f)
% 
% [vect_x,vect_r] = whittaker_iter(Ini,m,tol,f)

vect_x = []; 
vect_r = [];
x = Ini;
r = Inf;
while abs(r)>tol || abs(f(x))>tol
    x1 = x - f(x)/m;
    r = abs((x1-x)/x1);
    
    vect_x = [vect_x;x]; 
    vect_r = [vect_r;r]; 
    
    x = x1;
end
