clear all
format long

x0 = input("Escriu x0\n");
x1 = input("Escriu x1\n");
m = input("Escriu el parametre m\n");
tol = input("Escriu la tolerancia\n");
[vect_x1,vect_r1] = biseccio_iter([x0, x1],tol,@polinomi);
%x=linspace(-2,2,100); figure(1), plot(x,polinomi2(x))
%x0 = input("Escriu l'aproximacio inicial\n");
%m = input("Escriu el parametre m\n");
%tol = input("Escriu la tolerancia\n");
[vect_x2,vect_r2] = newton_iter(x0,tol,@polinomi,@derivada);
[vect_x3,vect_r3] = secant_iter([x0,x1],tol,@polinomi);
[vect_x4,vect_r4] = whittaker_iter(x0,m,tol,@polinomi);
vect_x2
i1 = 1:length(vect_r1);
i2 = 1:length(vect_r2);
i3 = 1:length(vect_r3);
i4 = 1:length(vect_r4);
figure(1), semilogy(i1,vect_r1(i1),'-d',i2,vect_r2(i2),'-o',i3,vect_r3(i3),'-x',i4,vect_r4(i4),'-s')
