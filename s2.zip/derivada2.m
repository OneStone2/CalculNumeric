function y = derivada2(x)
q = [1, -2, -6, 12, 9, -18];
y = polyval(polyder(q), x);
