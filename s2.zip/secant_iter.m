function [vect_x,vect_r] = secant_iter(Ini,tol,f)
% 
% [vect_x,vect_r] = secant_iter(Ini,tol,f)

vect_x = []; 
vect_r = [];
x0 = Ini(1); f0 = f(x0); 
x1 =  Ini(2); f1 = f(x1); 
r = Inf;
while abs(r)>tol || abs(f(x1))>tol
    x2 = x1 - f(x1)*(x1-x0)/(f1-f0);
    r = abs((x2-x1)/x2);
    
    vect_x = [vect_x;x2]; 
    vect_r = [vect_r;r]; 
    
    x0 = x1;
    x1 = x2;
    f0 = f1;
    f1 = f(x1);
end
