clear; close all; clc

load malla.mat
#plotMesh(X,T)

F = @(y)(calculaDistorsioMalla([reshape(y,Nint,2);X(Nint+1:end,:)],T));

y0 =  reshape(X(1:Nint,:),2*Nint,1);
tol = 1e-8; maxIter = 50; 

vect_y = [];
vect_r = [];
f = Inf;
r = Inf;

numericalDerivative(F, y0)(1)
numericalHessian(F, y0)(1, 1)

i = 0;
while i < maxIter && (r > tol || f > tol)
    f = numericalDerivative(F, y0);
    j1 = numericalHessian(F, y0);
    d1 = -j1\f;
    y1 = y0 + d1;
    r = norm(y1-y0)/norm(y1);
    
    vect_y = [vect_y, y0]; 
    vect_r = [vect_r, r]; 
    
    y0 = y1;
    i = i+1;
end

x = 1:length(vect_r);
figure(1), plot(x,log10(vect_r(x)),'-o')

X(1:Nint,:) = reshape(y0, Nint, 2);
#plotMesh(X,T);
#X(1,:)
#F(y0)
