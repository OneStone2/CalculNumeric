function distorsioMalla = calculaDistorsioMalla(X,T)
%
% distorsioMalla = calculaDistorsioMalla(X,T)

    A = [
        1  -sqrt(3)/3
        0   2*sqrt(3)/3
        ];

    n = rows(T);
    ds = 0;
    for i=1:n
        x1 = X(T(i, 1),:);
        x2 = X(T(i, 2),:);
        x3 = X(T(i, 3),:);
        D = [x2-x1;x3-x1]'*A;
        d = norm(D, 'fro')**2/(2*det(D));
        ds = ds + d**2;
    end
    distorsioMalla = ds**0.5;
end
