R = 0.00132;
g = -9.8;
v0 = 100;
theta = pi/4;
f=@(x,y) [y(3), y(4), -R*y(3)*sqrt(y(3)**2+y(4)**2), -R*y(4)*sqrt(y(3)**2+y(4)**2)+g]; a=0; b=10; y0=[0, 0, v0*cos(theta), v0*sin(theta)]; 
