function [x,Y]=Euler(f,I,y0,npassos)
a = I(1);
b = I(2);
h = (b-a)/npassos;
y1 = y0;
x = linspace(a, b, npassos+1);
Y = [y1];
for i=1:npassos
    d = f(x(i), y1);
    y1 = y1 + d*h;
    Y = [Y; y1];
end
