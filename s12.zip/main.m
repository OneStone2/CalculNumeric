close all;
%f=@(x,y) -y/(10*x+1); a=0; b=1;  y0=1;
f=@(x,y) [y(2), -y(1)]; a=0; b=2*pi;  y0=[1, 0];

%Solucio analitica
%yanal = @(x)(1./(1 + 10.*x).^(0.1));
yanal = @(x)(cos(x));

H = linspace(-3, 0);
H = 10.**H;

r = [];
for i=1:length(H)
    npassos=ceil((b-a)/H(i)); 
    [x,Y]=Euler(f,[a,b],y0,npassos);
    r = [r; abs(Y(end, 1)-yanal(b))];
end

figure(1)
hold on
plot(log10(H),log10(r),'-')
hold off;
