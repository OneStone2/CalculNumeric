function res=f3(t,y)
res=[y(2)
     -y(1)];