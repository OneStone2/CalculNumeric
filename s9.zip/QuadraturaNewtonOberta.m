function w = QuadraturaNewtonOberta(x, a, b)

A = [];
c = [];
xm = x(2:length(x)-1);
xm

for i=1:length(xm)
    A = [A; xm.^(i-1)];
    c = [c; b^i/i-a^i/i];
end
w = A\c;
