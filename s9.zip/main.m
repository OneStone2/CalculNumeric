%CONVERGENCIA DE LES QUADATURES COMPOSTES
%L'objectiu d'aquest exercici es comprovar la convergencia de les
%quadratures compostes. Aquest script mostra l'evolucio de l'error en 
%funcio del numero d'avaluacions de la funcio (cost) per a la quadratura 
%composta del trapezi. 
%
%Completa l'script per a dibuixar tambe l'evolucio de l'error per 
%a les quadratures compostes de:
% a) Simpson
% b) Gauss-Legendre amb 2 punts a cada subinterval (n=1)
% c) Gauss-Legendre amb 3 punts a cada subinterval (n=2)
%
%Observa la convergencia assimptotica. Tenen les quadratures el
%comportament esperat?
%
%Representa ara l'error per al segon exemple (paradoja de Runge).
%Compara l'evolucio de l'error amb l'error amb quadratures simples (1 sol
%interval, augmentant n)

clear all; close all; clc

%Exemple 1
%f = @(x)( exp(-x)+0.5*exp(-(x-4).^2) ); a = 0; b = 5; Iex = exp(-a) - exp(-b) + (1/4)*sqrt(pi)*(erf(b-4) - erf(a-4));
%Exemple 2
%f = @(x)(1./(1+x.^2)); a = -4; b = 4; Iex = (atan(b) - atan(a));
%Exemple 3
f = @(x)(x./sin(x)); a = 0; b = pi/2; Iex = quad(f, 0, pi/2);
%f = @(x)(x.**5); a = 0; b = 5; Iex = b**6/6;

%Canvi de variables per Gauss
f2 = @(t)(f((t+1).*(b-a)/2+a)*(b-a)/2);

errorNewtonO = [];
errorNewtonT = [];
errorGauss = [];
for n=1:14
    zno = linspace(a, b, n+3)(2:n+2);
    wno = QuadraturaNewton(zno, a, b);
    znt = linspace(a, b, n+1);
    wnt = QuadraturaNewton(znt, a, b);
    [zg, wg] = QuadraturaGauss(n+1);
    Ino = wno*(f(zno)');
    Int = wnt*(f(znt)');
    Ig = wg*(f2(zg));
    errorNewtonO = [errorNewtonO, abs(Ino-Iex)];
    errorNewtonT = [errorNewtonT, abs(Int-Iex)];
    errorGauss = [errorGauss, abs(Ig-Iex)];
end

%Grafica errors
figure(1) 
plot(1:14,log10(errorNewtonO),'-o', 1:14,log10(errorNewtonT),'-o', 1:14,log10(errorGauss),'-o') 
xlabel('(#punts)'), ylabel('log_{10}(error)')
legend('Newton-Cotes obert', 'Newton-Cotes tancat', 'Gauss-Legendre');

%fprintf('\nPendent 3 darrers punts:\n Composta trapezi: %0.1f \n',ajustTrap(1))
%fprintf('\nPendent 3 darrers punts:\n Composta Simpson: %0.1f \n',ajustSimp(1))
