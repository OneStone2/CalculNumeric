function w = QuadraturaNewton(x, a, b)

A = [];
c = [];

for i=1:length(x)
    A = [A; x.^(i-1)];
    c = [c; b^i/i-a^i/i];
end
w = A\c;
