function [Iaprox, x] = adaptativa(f,a,b,eps)

c = (a+b)/2;
I1 = simpson(f, a, c);
I2 = simpson(f, c, b);
I = simpson(f, a, b);
E = abs(I-I1-I2);

if E < eps*(b-a)
    Iaprox = I;
    x = [a];
else
    [IA1, x1] = adaptativa(f, a, c, eps);
    [IA2, x2] = adaptativa(f, c, b, eps);
    Iaprox = IA1 + IA2;
    x = [x1, x2];
end
