f = @(x)(sin(e.**(2.*x)));
a = 0;
b = 2;
eps = 1e-6;
[Iaprox, x1] = adaptativa(f, a, b, eps);
x1 = [x1, 2];

y1 = f(x1);
x2 = linspace(0,2,1000); 
y2 = f(x2); 
%plot(x1,zeros(1, length(x1)),'bo',x2,y2,'k-','LineWidth',0)
plot(x1,y1,'bo','LineWidth',0,x2,y2,'k-','LineWidth',1)
