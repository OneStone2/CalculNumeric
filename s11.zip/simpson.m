function Iaprox=simpson(f,a,b)

h = (b-a)/2;
m = (a+b)/2;
Iaprox = feval(f, a)*h/3+feval(f, m)*4*h/3+feval(f, b)*h/3;
