clear all
format long

x1 = input("Escriu x1 inicial\n");
x2 = input("Escriu x2 inicial\n");
x3 = input("Escriu x3 inicial\n");
x0 = [x1; x2; x3]
niter = input("Escriu el nombre d'iteracions\n");
[vect_x1,vect_r1] = newton_raphson(x0,niter,@f,@jacobiana)
[vect_x2,vect_r2] = newton_raphson_mod(x0,niter,@f,@jacobiana)
[vect_x3,vect_r3] = newton_raphson(x0,niter,@f,@jacobiana_numerica)
i1 = 1:length(vect_r1);
i2 = 1:length(vect_r2);
i3 = 1:length(vect_r3);
%i4 = 1:length(vect_r4);
%figure(1), semilogy(i1,vect_r1(i1),'-d',i2,vect_r2(i2),'-o',i3,vect_r3(i3),'-x',i4,vect_r4(i4),'-s')
%figure(1), semilogy(i1,vect_r1(i1),'-d',i2,vect_r2(i2),'-o')
figure(1), plot(i1,log10(vect_r1(i1)),'-d',i2,log10(vect_r2(i2)),'-o',i3,log10(vect_r3(i3)),'-x')
