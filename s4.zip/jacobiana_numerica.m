function y = jacobiana_numerica(x)
h = 1;
f = @f;
e1 = [1;0;0]; e2 = [0;1;0]; e3 = [0;0;1];
y1 = (f(x+h*e1)-f(x))/h;
y2 = (f(x+h*e2)-f(x))/h;
y3 = (f(x+h*e3)-f(x))/h;
y = [y1, y2, y3];
