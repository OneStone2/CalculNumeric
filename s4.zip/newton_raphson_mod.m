function [vect_x,vect_r] = newton_raphson_mod(Ini,niter,f,jacobiana)
% 
% [vect_x,vect_r] = newton_raphson_mod(Ini,niter,f,jacobiana)

vect_x = []; 
vect_r = [];
x = Ini;
r = Inf;
i = 0;
j1 = jacobiana(x);
%while abs(r)>tol || abs(f(x))>tol
while i < niter
    f1 = f(x);
    d1 = j1\f1;
    x1 = x - d1;
    r = norm((x1-x)/x1);
    
    vect_x = [vect_x,x]; 
    vect_r = [vect_r,r]; 
    
    x = x1;
    i = i+1;
end
